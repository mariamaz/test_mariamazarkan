<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Preferedshop extends Model
{
    //*
    protected $table= "preferedshops";
}
